import sqlite3
import os
import secrets
from datetime import datetime
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)

# مفتاح أمني قوي
app.secret_key = secrets.token_hex(32)

# منع رفع ملفات كبيرة
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50MB

# مجلدات التحميل
UPLOAD_IMAGES = "static/uploads/images"
UPLOAD_VIDEOS = "static/uploads/videos"

ALLOWED_IMAGES = {"png", "jpg", "jpeg", "gif"}
ALLOWED_VIDEOS = {"mp4", "webm", "ogg"}

for folder in [UPLOAD_IMAGES, UPLOAD_VIDEOS]:
    os.makedirs(folder, exist_ok=True)

# الاتصال بقاعدة البيانات
def get_db():
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    return conn

# إنشاء الجداول
def init_db():
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        category TEXT NOT NULL,
        image TEXT,
        video TEXT,
        created_at TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT
    )
    """)

    # إنشاء أدمن
    admin = cursor.execute("SELECT * FROM users WHERE username='admin'").fetchone()
    if not admin:
        password_hash = generate_password_hash("StrongAdmin#2026")
        cursor.execute(
            "INSERT INTO users (username,password) VALUES (?,?)",
            ("admin", password_hash)
        )

    conn.commit()
    conn.close()

init_db()

# حماية الصفحات
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated

# التحقق من الملفات
def allowed_file(filename, allowed):
    return "." in filename and filename.rsplit(".",1)[1].lower() in allowed

# الصفحة الرئيسية
@app.route("/")
def index():
    category = request.args.get("category")

    conn = get_db()

    if category:
        posts = conn.execute(
            "SELECT * FROM posts WHERE category=? ORDER BY id DESC",
            (category,)
        ).fetchall()
    else:
        posts = conn.execute(
            "SELECT * FROM posts ORDER BY id DESC"
        ).fetchall()

    conn.close()
    return render_template("index.html", posts=posts)

# تسجيل الدخول
@app.route("/login", methods=["GET","POST"])
def login():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        conn = get_db()

        user = conn.execute(
            "SELECT * FROM users WHERE username=?",
            (username,)
        ).fetchone()

        conn.close()

        if user and check_password_hash(user["password"], password):

            session["user_id"] = user["id"]
            session["username"] = user["username"]

            flash("تم تسجيل الدخول")

            return redirect(url_for("admin"))

        flash("بيانات غير صحيحة")

    return render_template("login.html")

# تسجيل الخروج
@app.route("/logout")
def logout():
    session.clear()
    flash("تم تسجيل الخروج")
    return redirect(url_for("index"))

# لوحة التحكم
@app.route("/admin")
@login_required
def admin():

    conn = get_db()

    posts = conn.execute(
        "SELECT * FROM posts ORDER BY id DESC"
    ).fetchall()

    conn.close()

    return render_template("admin.html", posts=posts)

# إضافة مقال
@app.route("/add", methods=["GET","POST"])
@login_required
def add():

    if request.method == "POST":

        title = request.form["title"]
        content = request.form["content"]
        category = request.form["category"]

        created_at = datetime.now().strftime("%Y-%m-%d %H:%M")

        image = request.files.get("image")
        video = request.files.get("video")

        image_name = None
        video_name = None

        if image and allowed_file(image.filename, ALLOWED_IMAGES):
            image_name = secure_filename(image.filename)
            image.save(os.path.join(UPLOAD_IMAGES, image_name))

        if video and allowed_file(video.filename, ALLOWED_VIDEOS):
            video_name = secure_filename(video.filename)
            video.save(os.path.join(UPLOAD_VIDEOS, video_name))

        conn = get_db()

        conn.execute("""
        INSERT INTO posts (title,content,category,image,video,created_at)
        VALUES (?,?,?,?,?,?)
        """,(title,content,category,image_name,video_name,created_at))

        conn.commit()
        conn.close()

        flash("تم نشر المقال")

        return redirect(url_for("admin"))

    return render_template("add.html")

# تعديل مقال
@app.route("/edit/<int:id>", methods=["GET", "POST"])
@login_required
def edit(id):
    conn = get_db()
    post = conn.execute("SELECT * FROM posts WHERE id=?", (id,)).fetchone()
    if not post:
        conn.close()
        abort(404)

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        content = request.form.get("content", "").strip()
        category = request.form.get("category", "").strip()
        if not title or not content or not category:
            conn.close()
            flash("يرجى ملء جميع الحقول المطلوبة")
            return redirect(url_for("edit", id=id))

        image_name = post["image"]
        video_name = post["video"]
        image = request.files.get("image")
        video = request.files.get("video")

        if image and image.filename and allowed_file(image.filename, ALLOWED_IMAGES):
            image_name = secure_filename(image.filename)
            image.save(os.path.join(UPLOAD_IMAGES, image_name))
        if video and video.filename and allowed_file(video.filename, ALLOWED_VIDEOS):
            video_name = secure_filename(video.filename)
            video.save(os.path.join(UPLOAD_VIDEOS, video_name))

        conn.execute(
            "UPDATE posts SET title=?, content=?, category=?, image=?, video=? WHERE id=?",
            (title, content, category, image_name, video_name, id)
        )
        conn.commit()
        conn.close()
        flash("تم تعديل المقال")
        return redirect(url_for("admin"))

    conn.close()
    return render_template("edit.html", post=post)

# حذف مقال
@app.route("/delete/<int:id>")
@login_required
def delete(id):

    conn = get_db()

    post = conn.execute(
        "SELECT * FROM posts WHERE id=?",
        (id,)
    ).fetchone()

    if not post:
        abort(404)

    if post["image"]:
        path = os.path.join(UPLOAD_IMAGES, post["image"])
        if os.path.exists(path):
            os.remove(path)

    if post["video"]:
        path = os.path.join(UPLOAD_VIDEOS, post["video"])
        if os.path.exists(path):
            os.remove(path)

    conn.execute(
        "DELETE FROM posts WHERE id=?",
        (id,)
    )

    conn.commit()
    conn.close()

    flash("تم حذف المقال")

    return redirect(url_for("admin"))

# تشغيل التطبيق
if __name__ == "__main__":
    app.run()